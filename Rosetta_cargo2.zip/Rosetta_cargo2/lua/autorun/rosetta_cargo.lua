--Add Playermodel
player_manager.AddValidModel( "Rosetta in Cargo", "models/vpva/pgr/Rosetta_cargo1.mdl" )


